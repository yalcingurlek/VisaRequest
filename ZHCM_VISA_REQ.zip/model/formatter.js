jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},
		setButton: function(status) {
			switch (status) {
				case "01":
					status = true;
					break;
				case "02":
					status = false;
					break;
				case "03":
					status = false;
					break;
				case "04":
					status = false;
					break;
				case "05":
					status = true;
					break;
				case "06":
					status = true;
					break;
				default:
					status = false;
					break;
			}

			return status;
		},
		VisaType: function(status) {
			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
			if(sCurrentLocale.indexOf("AR") > -1 || sCurrentLocale.indexOf("ar") > -1){
				switch (status) {
					case "0":
						status = "";
						break;
					case "S":
						status = "مفردة";
						break;
					case "M":
						status = "متعددة";
						break;
					default:
						status = "";
						break;
				}
	
				return status;
			}
			else{
				switch (status) {
					case "0":
						status = "";
						break;
					case "S":
						status = "Single";
						break;
					case "M":
						status = "Multiple";
						break;
					default:
						status = "None";
						break;
				}
	
				return status;
			}
		},
		statusState: function(status) {
			switch (status) {
				case "01":
					status = "Warning";
					break;
				case "02":
					status = "Success";
					break;
				case "03":
					status = "Error";
					break;
				case "04":
					status = "Success";
					break;
				case "05":
					status = "Warning";
					break;
				case "06":
					status = "None";
					break;
				default:
					status = "None";
					break;
			}

			return status;
		},
		formatDate: function(formatdate) {
			var oDateCreatedOn = "";
			var oType = new sap.ui.model.type.Date({
				style: "medium"
					//pattern: "MMM dd, yyyy"
			});
			if (formatdate) {
				oDateCreatedOn = oType.oOutputFormat.format(formatdate, true);
			}
			return oDateCreatedOn;
		},
		ToNumber: function(num) {
			return parseInt(num);
		},
		getRelativeMediaSrc: function(sMediaSrc) {
			var sUrl = "";
			if (sMediaSrc && typeof sMediaSrc === "string") {
				/* eslint-disable sap-browser-api-error */
				var oLink = document.createElement("a");
				/* eslint-enable sap-browser-api-error */
				oLink.href = sMediaSrc;
				sUrl = (oLink.pathname.charAt(0) === "/") ? oLink.pathname : "/" + oLink.pathname;
			}
			return sUrl;
		},
		formatDateNote: function(date, time) {
			var oDateCreatedOn = "";
			var oType = new sap.ui.model.type.Date({
				style: "medium"
					//pattern: "MMM dd, yyyy"
			});
			if (date) {
				oDateCreatedOn = oType.oOutputFormat.format(date, true);
			}
			var seconds = time.ms / 1000;
			// 2- Extract hours:
			var hours = parseInt(seconds / 3600); 
			seconds = seconds % 3600; 
			var minutes = parseInt(seconds / 60); // 60 seconds in 1 minute
			seconds = seconds % 60;
			
			var timeStr = hours + ":" + minutes + ":" + seconds;

			return oDateCreatedOn + " " + timeStr;

		}
	};

});