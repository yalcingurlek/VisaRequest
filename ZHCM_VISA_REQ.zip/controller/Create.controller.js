sap.ui.define([
	"visarequest/ZHCM_Visa_Request/controller/BaseController",
	"sap/m/MessageToast",
	"visarequest/ZHCM_Visa_Request/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"visarequest/ZHCM_Visa_Request/model/models"
], function(BaseController, MessageToast, formatter, JSONModel, MessageBox, models) {
	"use strict";

	return BaseController.extend("visarequest.ZHCM_Visa_Request.controller.Create", {
		formatter: formatter,

		onInit: function() {

			var oRouter = this.getRouter();
			oRouter.getRoute("create").attachPatternMatched(this._onObjectMatched, this);

		},
		_onObjectMatched: function(oEvent) {
			if (oEvent.getParameter("name") === "create") {
				var oViewModel = new JSONModel({
					VisaType: "",
					RequestReason: "",
					PaymentAmopunt: "",
					Paid: "",
					PeriodType: "",
					DepartureDate: "",
					ReturnDate: ""
				});

				this.getView().setModel(oViewModel, "createView");
			}
			this.setEmpty();
		},
		setEmpty: function() {

			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();

			var oModel = this.getView().getModel("Constant");
			var oData = oModel.getData();
			for (var i = 0; i < oData.Paid.length; i++) {
				oData.Paid[i].RequestType = false;

				if (sCurrentLocale.indexOf("AR") > -1 || sCurrentLocale.indexOf("ar") > -1) {
					switch (oData.Paid[i].Text) {
						case "Yes":
							oData.Paid[i].Text = "نعم";
							break;
						case "No":
							oData.Paid[i].Text = "لا";
							break;
						default:
							break;
					}
				} else {
					var klm = 0;
				}

			}
			oModel.setData(oData);
		},
		getList: function() {
			var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView),
				oComponent = sap.ui.component(sComponentId);
			var master = oComponent.getRouter().getView("visarequest.ZHCM_Visa_Request.view.Master");
			var list = master.byId("list");
			return list;
		},
		changeVisa: function(oEvent) {
			var dp5 = this.getView().byId("labelDP5");
			var dp6 = this.getView().byId("labelDP6");
			var dp6_dt = this.getView().byId("DP6");
			var selected = oEvent.getParameter("selectedItem");
			var cPeriod = this.getView().byId("idComboBoxPeriod");
			cPeriod.setSelectedKey("00");
			var oTemplate = new sap.ui.core.Item({
				text: "{Constant>value}",
				key: "{Constant>key}"
			});
			if (selected.getKey() == "S") {
				cPeriod.bindItems({
					path: "Constant>/SinglePeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(true);
				dp6.setRequired(true);
				dp6.setVisible(true);
				dp6_dt.setValue(null);
				dp6_dt.setVisible(true);
			} else if (selected.getKey() == "M") {
				cPeriod.bindItems({
					path: "Constant>/MultiPeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(false);
				dp6.setRequired(false);
				dp6.setVisible(false);
				dp6_dt.setValue(null);
				dp6_dt.setVisible(false);
			}
		},
		onAfterRendering: function() {
			var dMinDate = new Date();
			var date = new Date(dMinDate.getFullYear(), dMinDate.getMonth(), dMinDate.getDate());
			var dPicker = this.byId("DP5");
			dPicker.setMinDate(date);
			dPicker.addEventDelegate({
				onAfterRendering: function() {
					dPicker.$().find("input").attr("readonly", true);
				}
			});

			var dPickerR = this.byId("DP6");
			dPickerR.setMinDate(date);
			dPickerR.addEventDelegate({
				onAfterRendering: function() {
					dPickerR.$().find("input").attr("readonly", true);
				}
			});

			var oComboBox = this.getView().byId("idComboBoxVisa");

			oComboBox.addEventDelegate({
				onAfterRendering: function() {
					oComboBox.$().find("input").attr("readonly", true);
				}
			});

			var oComboBox1 = this.getView().byId("idComboBoxPeriod");

			oComboBox1.addEventDelegate({
				onAfterRendering: function() {
					oComboBox1.$().find("input").attr("readonly", true);
				}
			});

			this.setType();
		},
		setType: function() {
			var array = "";
			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
			if (sCurrentLocale.indexOf("AR") > -1 || sCurrentLocale.indexOf("ar") > -1) {
				array = "Constant>/VisaTypeArabic";
			} else {
				array = "Constant>/VisaType";
			}
			var oTemplate = new sap.ui.core.Item({
				text: "{Constant>value}",
				key: "{Constant>key}"
			});
			this.getView().byId("idComboBoxVisa").bindItems({
				path: array,
				template: oTemplate,
				templateShareable: true
			});
		},
		onSave: function() {
			var oDataModel = this.getView().getModel(),
				that = this,
				oView = this.getView(),
				eInitialModel = this.getView().getModel("EmployeeInfo"),
				eInitialData = eInitialModel.getData(),
				oParams = {},
				oEntry = {};
			var bModel = this.getView().getModel("createView");
			var bData = bModel.getData();
			var DepartureDate = this.getView().byId("DP5"),
				ReturnDate = this.getView().byId("DP6");

			if (this.checkObligotary(bData)) {
				MessageBox.show(this.getMessage("areYouSureYouWantToSave"), {
					icon: sap.m.MessageBox.Icon.QUESTION,
					title: "",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: this.getOwnerComponent().getContentDensityClass(),
					onClose: function(oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							oEntry.EmployeeId = eInitialData.EmployeeId;
							oEntry.VisaType = bData.VisaType;
							oEntry.RequestReason = bData.RequestReason;
							oEntry.PaymentCurrency = "";
							oEntry.Paid = this.setPaid(bData.Paid);
							if (oEntry.Paid) {
								oEntry.PaymentAmount = bData.PaymentAmount;
							} else {
								oEntry.PaymentAmount = "0";
							}
							oEntry.TimePeriod = bData.PeriodType;
							oEntry.DepartureDate = this._getUTCDate(DepartureDate.getDateValue());
							oEntry.ReturnDate = this._getUTCDate(ReturnDate.getDateValue());
							oEntry.VisaStatu = "06";

							oParams.success = function(oData2, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								models.createEmployeeInitialsModel(this.getOwnerComponent());
								MessageToast.show(this.getMessage("successfulSaved"));
								var sPath = "/VisaRequestSet(EmployeeId='" + oData2.EmployeeId + "',TicketAssurance='" + oData2.VisaRequest + "')";
								this.getOwnerComponent().oListSelector.selectAListItem(sPath);
								this.getRouter().navTo("change", {
									EmployeeId: oData2.EmployeeId,
									VisaRequest: oData2.VisaRequest
								}, true); //do not write history this page
							}.bind(this);

							oParams.error = function(oError) {
								sap.ui.core.BusyIndicator.hide();
								that.showError(that.getErrorMessage(oError));
							}.bind(this);

							oParams.async = true;
							sap.ui.core.BusyIndicator.show(0);
							oDataModel.create("/VisaRequestSet", oEntry, oParams);
						}
					}.bind(this)
				});

			} else {
				MessageToast.show(this.getMessage("notEmpty"));
			}
		},
		onSend: function() {
			var oDataModel = this.getView().getModel(),
				that = this,
				oView = this.getView(),
				eInitialModel = this.getView().getModel("EmployeeInfo"),
				eInitialData = eInitialModel.getData(),
				oParams = {},
				oEntry = {};
			var bModel = this.getView().getModel("createView");
			var bData = bModel.getData();
			var DepartureDate = this.getView().byId("DP5"),
				ReturnDate = this.getView().byId("DP6");

			if (this.checkObligotary(bData)) {
				MessageBox.show(this.getMessage("areYouSureYouWantToCreate"), {
					icon: sap.m.MessageBox.Icon.QUESTION,
					title: "",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: this.getOwnerComponent().getContentDensityClass(),
					onClose: function(oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							oEntry.EmployeeId = eInitialData.EmployeeId;
							oEntry.VisaType = bData.VisaType;
							oEntry.RequestReason = bData.RequestReason;
							oEntry.PaymentCurrency = "";
							oEntry.Paid = this.setPaid(bData.Paid);
							if (oEntry.Paid) {
								oEntry.PaymentAmount = bData.PaymentAmount;
							} else {
								oEntry.PaymentAmount = "0";
							}
							oEntry.TimePeriod = bData.PeriodType;
							oEntry.DepartureDate = this._getUTCDate(DepartureDate.getDateValue());
							oEntry.ReturnDate = this._getUTCDate(ReturnDate.getDateValue());
							oEntry.VisaStatu = "01";
							oParams.success = function(oData2, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								models.createEmployeeInitialsModel(this.getOwnerComponent());
								MessageToast.show(this.getMessage("successfulCreation"));
								var sPath = "/VisaRequestSet(EmployeeId='" + oData2.EmployeeId + "',TicketAssurance='" + oData2.VisaRequest + "')";
								this.getOwnerComponent().oListSelector.selectAListItem(sPath);
								this.getRouter().navTo("detail", {
									EmployeeId: oData2.EmployeeId,
									VisaRequest: oData2.VisaRequest
								}, true); //do not write history this page
							}.bind(this);

							oParams.error = function(oError) {
								sap.ui.core.BusyIndicator.hide();
								that.showError(that.getErrorMessage(oError));
							}.bind(this);

							oParams.async = true;
							sap.ui.core.BusyIndicator.show(0);
							oDataModel.create("/VisaRequestSet", oEntry, oParams);
						}
					}.bind(this)
				});

			} else {
				MessageToast.show(this.getMessage("notEmpty"));
			}
		},
		showError: function(text) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				text, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		getErrorMessage: function(response) {
			var message = jQuery.parseJSON(response.responseText).error.message.value;
			return message;
		},
		setPaid: function(paid) {
			if (paid == "0")
				return true;
			else
				return false;
		},
		checkObligotary: function(user) {
			var selected = this.getView().byId("idComboBoxVisa").getSelectedItem();

			if (selected) {
				if (selected.getKey() === "S") {
					if (user.Paid && user.Paid !== "" &&
						user.VisaType && user.VisaType !== "" &&
						user.RequestReason && user.RequestReason !== "" &&
						user.DepartureDate && user.DepartureDate !== "" &&
						user.ReturnDate && user.ReturnDate !== "" &&
						user.PeriodType !== "00" && user.PeriodType && user.PeriodType !== "") {
						if (user.Paid === "0" && user.PaymentAmount !== "" && user.PaymentAmount) {
							return true;
						} else if (user.Paid === "1") {
							return true;
						} else {
							return false;
						}

					} else
						return false;
				} else if (selected.getKey() === "M") {
					if (user.Paid && user.Paid !== "" &&
						user.VisaType && user.VisaType !== "" &&
						user.RequestReason && user.RequestReason !== "" &&
						user.PeriodType !== "00" && user.PeriodType && user.PeriodType !== "") {
						if (user.Paid === "0" && user.PaymentAmount !== "" && user.PaymentAmount) {
							return true;
						} else if (user.Paid === "1") {
							return true;
						} else {
							return false;
						}
					} else
						return false;
				}
			} else {
				return false;
			}

		},
		onSelectPaid: function(oEvent) {
			var bModel = this.getView().getModel("createView");
			var bData = bModel.getData();
			bData.Paid = oEvent.getParameter("selectedIndex").toString();

			var paidText = this.getView().byId("idInputPaymentAmount");
			var paidTextLabel = this.getView().byId("idInputPaymentAmountLabel");
			if (bData.Paid == "0") {
				paidText.setVisible(true);
				paidTextLabel.setVisible(true);
			} else if (bData.Paid == "1") {
				paidText.setVisible(false);
				paidTextLabel.setVisible(false);
			}
			bModel.setData(bData);
		},
		getMessage: function(message) {
			var oModel = this.getView().getModel("i18n");
			var resourceBundle = oModel.getResourceBundle();
			return resourceBundle.getText(message);
		},
		onCancel: function() {
			var list = this.getList();
			if (list.getItems().length > 0) {
				var firstItem = list.getItems()[0];
				list.setSelectedItem(firstItem, true);
				this.getRouter().navTo("detail", {
					EmployeeId: firstItem.getBindingContext().getObject().EmployeeId,
					VisaRequest: firstItem.getBindingContext().getObject().VisaRequest
				});
			} else {
				if (!sap.ui.Device.system.phone) {
					this.getRouter().navTo("Error", {});
				}
			}
		},
		onStartingDateChanged: function(oEvent) {

			var dSelectedDate = oEvent.getSource().getDateValue();
			oEvent.getSource().setDateValue(dSelectedDate);
		},
		onStartingDateChangedReturn: function(oEvent) {

			var dSelectedDate = oEvent.getSource().getDateValue();

			var one_day = 1000 * 60 * 60 * 24;
			var date1_ms = this.getView().byId("DP5").getDateValue().getTime();
			var date2_ms = dSelectedDate.getTime(); // Calculate the difference in milliseconds  
			var difference_ms = date2_ms - date1_ms; // Convert back to days and return   
			var days = Math.round(difference_ms / one_day);
			if (days < 180 && days > 0) {
				oEvent.getSource().setDateValue(dSelectedDate);
			} else {
				oEvent.getSource().setDateValue();
				MessageToast.show(this.getMessage("timeError"));
			}
		},
		_getUTCDate: function(sDate) {
			if (sDate && sDate !== null) {
				return new Date(Date.UTC(sDate.getFullYear(), sDate.getMonth(), sDate.getDate(), sDate.getHours(),
					sDate.getMinutes(), sDate.getSeconds()));
			} else {
				return sDate;
			}
		},
		onChangeFile: function(oEvent) {
			var filename = encodeURIComponent(oEvent.getParameter("files")[0].name);
			var oModel = this.getView().getModel("i18n");
			var resourceBundle = oModel.getResourceBundle();
			this.showError(resourceBundle.getText("fileIssue", [filename]));
		}
	});

});