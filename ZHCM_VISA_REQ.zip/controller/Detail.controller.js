/*global location */
sap.ui.define([
	"visarequest/ZHCM_Visa_Request/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"visarequest/ZHCM_Visa_Request/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"visarequest/ZHCM_Visa_Request/model/models",
	"sap/ui/Device"
], function(BaseController, JSONModel, formatter, MessageBox, MessageToast, models, Device) {
	"use strict";

	return BaseController.extend("visarequest.ZHCM_Visa_Request.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});
			this.getView().setModel(oViewModel, "detailView");

			var oRouter = this.getRouter();
			oRouter.getRoute("detail").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			var view = this.getView();
			if (this.getView().byId("TabContainer").getSelectedKey() !== "Information") {
				this.getView().byId("TabContainer").setSelectedKey("Information");
			}
			if (oEvent.getParameter("name") === "detail") {
				var sVisaRequest = oEvent.getParameter("arguments").VisaRequest;
				var sEmployeeId = oEvent.getParameter("arguments").EmployeeId;
				//				this.AttachmentModel(sEmployeeId, sVisaRequest);
				this.getView().getModel().metadataLoaded().then(function() {
					var sObjectPath = this.getView().getModel().createKey("VisaRequestSet", {
						EmployeeId: sEmployeeId,
						VisaRequest: sVisaRequest
					});
					this._bindView("/" + sObjectPath);
					this.callValueHelps("/" + sObjectPath);
				}.bind(this));

			}

		},
		callValueHelps: function(contextPath) {
			sap.ui.core.BusyIndicator.show(0);
			var oModel = this.getView().getModel();
			var mParameters = {
				urlParameters: {
					"$expand": "VisaRequestToAttachment,VisaRequestToNote"
				},

				success: function(oData) {

					var AttachmentsJSON = null;
					AttachmentsJSON = oData.VisaRequestToAttachment;
					var attachElement = this.getView().byId("AttchmentTab");
					if (AttachmentsJSON.results.length > 0) {
						attachElement.setVisible(true);
						attachElement.setCount(AttachmentsJSON.results.length);
					} else {
						attachElement.setVisible(false);
					}
					for (var i = 0; i < AttachmentsJSON.results.length; i++) {
						if (!AttachmentsJSON.results[i].Url) {
							AttachmentsJSON.results[i].Url = AttachmentsJSON.results[i].__metadata.media_src;
						}
					}
					var oAttachmentsModel = new sap.ui.model.json.JSONModel(AttachmentsJSON);
					this.getView().setModel(oAttachmentsModel, "Attachment");

					var AttachmentsJSONNote = null;
					AttachmentsJSONNote = oData.VisaRequestToNote;

					var noteElement = this.getView().byId("MultiNotesTab");
					if (AttachmentsJSONNote.results.length > 0) {
						noteElement.setVisible(true);
						noteElement.setCount(AttachmentsJSONNote.results.length);
					} else {
						noteElement.setVisible(false);
					}

					var oAttachmentsModelNote = new sap.ui.model.json.JSONModel(AttachmentsJSONNote);
					this.getView().setModel(oAttachmentsModelNote, "Note");
				}.bind(this),

				error: function(oError) {

					jQuery.sap.log.info("Odata Error occured");

				}.bind(this)

			};
			oModel.read(contextPath, mParameters);
			sap.ui.core.BusyIndicator.hide();
		},
		onChange: function() {
			var oView = this.getView();

			this.getRouter().navTo("change", {
				EmployeeId: oView.getBindingContext().getProperty("EmployeeId"),
				VisaRequest: oView.getBindingContext().getProperty("VisaRequest")
			}, false);
		},
		getList: function() {
			var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView),
				oComponent = sap.ui.component(sComponentId);
			var master = oComponent.getRouter().getView("visarequest.ZHCM_Visa_Request.view.Master");
			var list = master.byId("list");
			return list;
		},
		onWithdrawn: function() {

			var oView = this.getView(),
				oDataModel = oView.getModel();
			var that = this;
			MessageBox.show(this.getMessage("areYouSureYouWantToWithdraw"), {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				styleClass: this.getOwnerComponent().getContentDensityClass(),
				onClose: function(oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {

						var oParams = {};
						oParams.method = "POST";
						oParams.success = function(oData, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(this.getMessage("successfulWithdrawal"));
							// this._bindView(oView.getBindingContext().sPath);
							oDataModel.refresh(true, true);
							models.createEmployeeInitialsModel(this.getOwnerComponent());
							// that.setFirstItem();
						}.bind(this);

						oParams.error = function(oError) {
							sap.ui.core.BusyIndicator.hide();
							that.showError(that.getErrorMessage(oError));
						}.bind(this);

						oParams.async = true;
						sap.ui.core.BusyIndicator.show(0);
						oDataModel.remove(oView.getBindingContext().sPath, oParams);
					}
				}.bind(this)
			});
		},
/*		setFirstItem: function() {
			var bReplace = !Device.system.phone;
			if (this.getList().getItems().length > 0) {
				var firstItem = this.getList().getItems()[0];
				this.getList().setSelectedItem(firstItem, true);
				this.getList().setSelectedItem(firstItem);
				this.getRouter().navTo("detail", {
					EmployeeId: firstItem.getBindingContext().sPath.split("'")[1],
					VisaRequest: firstItem.getBindingContext().sPath.split("'")[3]
				}, bReplace);
			}

		},*/
		showError: function(text) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				text, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		getErrorMessage: function(response) {
			var message = jQuery.parseJSON(response.responseText).error.message.value;
			return message;
		},
		getMessage: function(message) {
			var oModel = this.getView().getModel("i18n");
			var resourceBundle = oModel.getResourceBundle();
			return resourceBundle.getText(message);
		},
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getView().getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},
		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath();

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
		},

		_onMetadataLoaded: function() {
				// Store original busy indicator delay for the detail view
				var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
					oViewModel = this.getModel("detailView"),
					oLineItemTable = this.byId("lineItemsList"),
					iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

				// Make sure busy indicator is displayed immediately when
				// detail view is displayed for the first time
				oViewModel.setProperty("/delay", 0);
				oViewModel.setProperty("/lineItemTableDelay", 0);

				oLineItemTable.attachEventOnce("updateFinished", function() {
					// Restore original busy indicator delay for line item table
					oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
				});

				// Binding the view will set it to not busy - so the view is always busy if it is not bound
				oViewModel.setProperty("/busy", true);
				// Restore original busy indicator delay for the detail view
				oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
			}
			/*	AttachmentModel: function(EmployeeId, VisaRequest) {
					var oDataModel = this.getView().getModel(),
						Attachment = new JSONModel({
							IsCreatable: false
						}),
						oFunctionParams = {};

					this.getView().setModel(Attachment, "Attachment");
					var that = this;
					var paramaters = {
						"EmployeeId": EmployeeId,
						"VisaRequest": VisaRequest
					};
					oFunctionParams.urlParameters = paramaters;
					oFunctionParams.method = "GET";
					oFunctionParams.success = function(oData, oResponse) {
						delete oData.__metadata;
						for (var i = 0; i < oData.results.length; i++) {
							if (!oData.results[i].Url) {
								oData.results[i].Url = oData.results[i].__metadata.media_src;
							}
						}
						Attachment.setData(oData);
						that.getView().setModel(Attachment, "Attachment");
					};

					oFunctionParams.error = function(oError) {

						that.getView()._oErrorHandler._bMessageOpen = true;

						var jsonError = JSON.parse(oError.responseText);
						Attachment.setData({
							IsCreatable: false,
							ErrorMessage: jsonError.error.message.value
						});

						that.getView().setModel(Attachment, "Attachment");

						MessageBox.error(
							// this._sErrorText,
							jsonError.error.message.value, {
								id: "serviceErrorMessageBox",
								details: oError,
								styleClass: that.getView().getContentDensityClass(),
								actions: [MessageBox.Action.CLOSE],
								onClose: function() {
									that.getView()._oErrorHandler._bMessageOpen = false;
									that.getView().getRouter().getTargets().display("error");
								}.bind(that)
							}
						);

					};
					oFunctionParams.async = false;

					oDataModel.metadataLoaded().then(function() {
						oDataModel.callFunction("/GetAttachment", oFunctionParams);
					}.bind(this));

				}*/

	});

});