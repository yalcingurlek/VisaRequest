jQuery.sap.require("visarequest.ZHCM_Visa_Request.model.FileUploadHelper");
sap.ui.define([
	"visarequest/ZHCM_Visa_Request/controller/BaseController",
	"sap/m/MessageToast",
	"visarequest/ZHCM_Visa_Request/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"visarequest/ZHCM_Visa_Request/model/models"
], function(BaseController, MessageToast, formatter, JSONModel, MessageBox, models) {
	"use strict";

	return BaseController.extend("visarequest.ZHCM_Visa_Request.controller.Change", {
		formatter: formatter,

		onInit: function() {

			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.getRouter().getRoute("change").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

		},
		_onObjectMatched: function(oEvent) {
			var view = this.getView();
			this.oFileUploadControl = this.getView().byId("oUploadCollection");
			var context = new sap.ui.model.Context(view.getModel(), "/" + oEvent.getParameter("arguments").contextPath);
			this.oContext = context;
			this.sVisaRequest = oEvent.getParameter("arguments").VisaRequest;
			this.sEmployeeId = oEvent.getParameter("arguments").EmployeeId;
			//this.AttachmentModel(this.sEmployeeId, this.sVisaRequest);
			this.getView().getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getView().getModel().createKey("VisaRequestSet", {
					EmployeeId: this.sEmployeeId,
					VisaRequest: this.sVisaRequest
				});
				this._bindView("/" + sObjectPath);
				this.callValueHelps("/" + sObjectPath);

			}.bind(this));
		},
		callValueHelps: function(contextPath) {

			var oModel = this.getView().getModel();
			var mParameters = {
				urlParameters: {
					"$expand": "VisaRequestToAttachment"
				},

				success: function(oData) {

					var AttachmentsJSON = null;
					AttachmentsJSON = oData.VisaRequestToAttachment;
					for (var i = 0; i < AttachmentsJSON.results.length; i++) {
						if (!AttachmentsJSON.results[i].Url) {
							AttachmentsJSON.results[i].Url = AttachmentsJSON.results[i].__metadata.media_src;
						}
					}
					var oAttachmentsModel = new sap.ui.model.json.JSONModel(AttachmentsJSON);
					this.getView().setModel(oAttachmentsModel, "Attachment");
				}.bind(this),

				error: function(oError) {

					jQuery.sap.log.info("Odata Error occured");

				}.bind(this)

			};
			oModel.read(contextPath, mParameters);
		},
		getList: function() {
			var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView),
				oComponent = sap.ui.component(sComponentId);
			var master = oComponent.getRouter().getView("visarequest.ZHCM_Visa_Request.view.Master");
			var list = master.byId("list");
			return list;
		},
		changeVisa: function(oEvent) {
			var dp5 = this.getView().byId("labelDP5");
			var dp6 = this.getView().byId("labelDP6");
			var dp6_dt = this.getView().byId("DP6");
			var selected = oEvent.getParameter("selectedItem");
			var cPeriod = this.getView().byId("idComboBoxPeriod");
			cPeriod.setSelectedKey("00");
			var oTemplate = new sap.ui.core.Item({
				text: "{Constant>value}",
				key: "{Constant>key}"
			});
			if (selected.getKey() == "S") {
				cPeriod.bindItems({
					path: "Constant>/SinglePeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(true);
				dp6.setRequired(true);
				dp6.setVisible(true);
				dp6_dt.setValue(null);
				dp6_dt.setVisible(true);
			} else if (selected.getKey() == "M") {
				cPeriod.bindItems({
					path: "Constant>/MultiPeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(false);
				dp6.setRequired(false);
				dp6.setVisible(false);
				dp6_dt.setValue(null);
				dp6_dt.setVisible(false);
			}
		},
		visaInit: function(visa) {
			var dp5 = this.getView().byId("labelDP5");
			var dp6 = this.getView().byId("labelDP6");
			var dp6_dt = this.getView().byId("DP6");
			var cPeriod = this.getView().byId("idComboBoxPeriod");
			var oTemplate = new sap.ui.core.Item({
				text: "{Constant>value}",
				key: "{Constant>key}"
			});
			if (visa == "S") {
				cPeriod.bindItems({
					path: "Constant>/SinglePeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(true);
				dp6.setRequired(true);
				dp6.setVisible(true);
				dp6_dt.setVisible(true);
			} else if (visa == "M") {
				cPeriod.bindItems({
					path: "Constant>/MultiPeriod",
					template: oTemplate,
					templateShareable: true
				});
				dp5.setRequired(false);
				dp6.setRequired(false);
				dp6.setVisible(false);
				dp6_dt.setVisible(false);
			}
		},
		setSelected: function(PaidValue) {
			var oModel = this.getView().getModel("Constant");
			var oData = oModel.getData();
			var paidText = this.getView().byId("idPAmountInput");
			var paidTextLabel = this.getView().byId("idLabelPAmount");

			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();

			if (PaidValue != undefined) {
				if (PaidValue) {
					oData.Paid["0"].RequestType = true;
					paidText.setVisible(true);
					paidTextLabel.setVisible(true);
				} else {
					oData.Paid["1"].RequestType = true;
					paidText.setVisible(false);
					paidTextLabel.setVisible(false);
				}

				if (sCurrentLocale.indexOf("AR") > -1 || sCurrentLocale.indexOf("ar") > -1) {
					switch (oData.Paid["0"].Text) {
						case "Yes":
							oData.Paid["0"].Text = "نعم";
							break;
						case "No":
							oData.Paid["0"].Text = "لا";
							break;
						default:
							break;
					}
					switch (oData.Paid["1"].Text) {
						case "Yes":
							oData.Paid["1"].Text = "نعم";
							break;
						case "No":
							oData.Paid["1"].Text = "لا";
							break;
						default:
							break;
					}
				}

			}
			oModel.setData(oData);
		},
		onAfterRendering: function() {
			var dMinDate = new Date();
			var date = new Date(dMinDate.getFullYear(), dMinDate.getMonth(), dMinDate.getDate());
			var dPicker = this.byId("DP5");
			dPicker.setMinDate(date);
			dPicker.addEventDelegate({
				onAfterRendering: function() {
					dPicker.$().find("input").attr("readonly", true);
				}
			});

			var dPickerR = this.byId("DP6");
			dPickerR.setMinDate(date);
			dPickerR.addEventDelegate({
				onAfterRendering: function() {
					dPickerR.$().find("input").attr("readonly", true);
				}
			});

			var oComboBox = this.getView().byId("idComboBoxVisa");

			oComboBox.addEventDelegate({
				onAfterRendering: function() {
					oComboBox.$().find("input").attr("readonly", true);
				}
			});

			var oComboBox1 = this.getView().byId("idComboBoxPeriod");

			oComboBox1.addEventDelegate({
				onAfterRendering: function() {
					oComboBox1.$().find("input").attr("readonly", true);
				}
			});

			this.setType();
		},
		setType: function() {
			var array = "";
			var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
			if (sCurrentLocale.indexOf("AR") > -1 || sCurrentLocale.indexOf("ar") > -1) {
				array = "Constant>/VisaTypeArabic";
			} else {
				array = "Constant>/VisaType";
			}
			var oTemplate = new sap.ui.core.Item({
				text: "{Constant>value}",
				key: "{Constant>key}"
			});
			this.getView().byId("idComboBoxVisa").bindItems({
				path: array,
				template: oTemplate,
				templateShareable: true
			});
		},
		setPaidValue: function() {
			var oModel = this.getView().getModel("Constant");
			var oData = oModel.getData();
			for (var i = 0; i < oData.Paid.length; i++) {
				if (oData.Paid[i].RequestType === true) {
					return i;
				}
			}
		},
		onSend: function() {
			var oDataModel = this.getView().getModel(),
				oView = this.getView(),
				that = this,
				oParams = {},
				oEntry = {};
			var DepartureDate = this.getView().byId("DP5"),
				ReturnDate = this.getView().byId("DP6");
			var user = {};
			user.VisaType = oView.byId("idComboBoxVisa").getSelectedItem().getKey();
			user.RequestReason = oView.byId("idRReasonInput").getValue();

			//			user.PaymentAmount = oView.byId("idPAmountInput").getValue();
			user.Paid = this.setPaid(this.setPaidValue());
			if (user.Paid) {
				user.PaymentAmount = oView.byId("idPAmountInput").getValue();
			} else {
				user.PaymentAmount = "0";
			}
			user.TimePeriod = oView.byId("idComboBoxPeriod").getSelectedItem().getKey();
			var askRequest = "";
			var returnRequest = "";
			if (oView.getModel().getProperty(oView.getBindingContext().sPath).VisaStatu == "01" || oView.getModel().getProperty(oView.getBindingContext()
					.sPath).VisaStatu == "05") {
				askRequest = "areYouSureYouWantToChange";
				returnRequest = "successfulChange";
			} else if (oView.getModel().getProperty(oView.getBindingContext().sPath).VisaStatu == "06") {
				askRequest = "areYouSureYouWantToSubmit";
				returnRequest = "successfulSubmit";
			}

			if (this.checkObligotary(user, DepartureDate, ReturnDate)) {
				MessageBox.show(this.getMessage(askRequest), {
					icon: sap.m.MessageBox.Icon.QUESTION,
					title: "",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					styleClass: this.getOwnerComponent().getContentDensityClass(),
					onClose: function(oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							oEntry.EmployeeId = oView.getBindingContext().getProperty("EmployeeId");
							oEntry.VisaType = user.VisaType;
							oEntry.RequestReason = user.RequestReason;
							oEntry.PaymentAmount = user.PaymentAmount;
							oEntry.PaymentCurrency = "";
							oEntry.Paid = user.Paid;
							oEntry.TimePeriod = user.TimePeriod;
							oEntry.DepartureDate = this._getUTCDate(DepartureDate.getDateValue());
							oEntry.ReturnDate = this._getUTCDate(ReturnDate.getDateValue());
							oParams.success = function(oData2, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(this.getMessage(returnRequest));
								var sPath = oView.getBindingContext().sPath;
								this.getOwnerComponent().oListSelector.selectAListItem(sPath);
								this.getRouter().navTo("detail", {
									EmployeeId: oView.getBindingContext().getProperty("EmployeeId"),
									VisaRequest: oView.getBindingContext().getProperty("VisaRequest")
								}, true); //do not write history this page
							}.bind(this);

							oParams.error = function(oError) {
								sap.ui.core.BusyIndicator.hide();
								that.showError(that.getErrorMessage(oError));
								var sPath = oView.getBindingContext().sPath;
								this.getOwnerComponent().oListSelector.selectAListItem(sPath);
							}.bind(this);

							oParams.async = true;
							sap.ui.core.BusyIndicator.show(0);
							oDataModel.update(oView.getBindingContext().sPath, oEntry, oParams);
						}
					}.bind(this)
				});

			} else {
				MessageToast.show(this.getMessage("notEmpty"));
			}
		},
		showError: function(text) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.error(
				text, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},
		getErrorMessage: function(response) {
			var message = jQuery.parseJSON(response.responseText).error.message.value;
			return message;
		},
		setPaid: function(paid) {
			if (paid == 0)
				return true;
			else
				return false;
		},
		checkObligotary: function(user, DepartureDate, ReturnDate) {
			var selected = this.getView().byId("idComboBoxVisa").getSelectedItem();

			if (selected) {
				if (selected.getKey() === "S") {
					if (user.Paid !== "" &&
						user.VisaType && user.VisaType !== "" &&
						user.RequestReason && user.RequestReason !== "" &&
						user.TimePeriod !== "00" && user.TimePeriod && user.TimePeriod !== "" &&
						DepartureDate.getDateValue() && DepartureDate.getDateValue() !== "" &&
						ReturnDate.getDateValue() && ReturnDate.getDateValue() !== "") {
						if (user.Paid === true && parseInt(user.PaymentAmount) !== 0) {
							return true;
						} else if (user.Paid === false) {
							return true;
						} else {
							return false;
						}
					} else
						return false;
				} else if (selected.getKey() === "M") {
					if (user.Paid !== "" &&
						user.VisaType && user.VisaType !== "" &&
						user.RequestReason && user.RequestReason !== "" &&
						user.PaymentAmount && user.PaymentAmount !== "" &&
						user.TimePeriod !== "00" && user.TimePeriod && user.TimePeriod !== "") {
						if (user.Paid === true && parseInt(user.PaymentAmount) !== 0) {
							return true;
						} else if (user.Paid === false) {
							return true;
						} else {
							return false;
						}
					} else
						return false;
				}
			} else {
				return false;
			}

		},
		onSelectPaid: function(oEvent) {
			var paid = oEvent.getParameter("selectedIndex").toString();
			var paidText = this.getView().byId("idPAmountInput");
			var paidTextLabel = this.getView().byId("idLabelPAmount");
			if (paid == "0") {
				paidText.setVisible(true);
				paidTextLabel.setVisible(true);
			} else if (paid == "1") {
				paidText.setVisible(false);
				paidTextLabel.setVisible(false);
			}
		},
		getMessage: function(message) {
			var oModel = this.getView().getModel("i18n");
			var resourceBundle = oModel.getResourceBundle();
			return resourceBundle.getText(message);
		},
		onCancel: function() {
			var oDataModel = this.getModel(),
				oView = this.getView();

			oDataModel.resetChanges();

			this.getRouter().navTo("detail", {
				EmployeeId: oView.getBindingContext().getProperty("EmployeeId"),
				VisaRequest: oView.getBindingContext().getProperty("VisaRequest")
			}, true);
		},
		onStartingDateChanged: function(oEvent) {

			var dSelectedDate = oEvent.getSource().getDateValue();
			var one_day = 1000 * 60 * 60 * 24;
			var date2_ms = "";
			if (this.getView().byId("DP6").getValue()) {
				if (this.getView().byId("DP6").getDateValue() == null) {
					date2_ms = new Date(this.getView().byId("DP5").getValue()).getTime();
				} else {
					date2_ms = this.getView().byId("DP6").getDateValue().getTime();
				}
				var date1_ms = dSelectedDate.getTime(); // Calculate the difference in milliseconds  
				var difference_ms = date2_ms - date1_ms; // Convert back to days and return   
				var days = Math.round(difference_ms / one_day);
				if (days < 180 && days > 0) {
					oEvent.getSource().setDateValue(dSelectedDate);
				} else {
					oEvent.getSource().setDateValue();
					MessageToast.show(this.getMessage("timeError"));
				}
			} else {
				oEvent.getSource().setDateValue(dSelectedDate);
			}
		},
		onStartingDateChangedReturn: function(oEvent) {
			var dSelectedDate = oEvent.getSource().getDateValue();

			var one_day = 1000 * 60 * 60 * 24;
			var date1_ms = "";
			if (this.getView().byId("DP5").getValue()) {
				if (this.getView().byId("DP5").getDateValue() == null) {
					date1_ms = new Date(this.getView().byId("DP5").getValue()).getTime();
				} else {
					date1_ms = this.getView().byId("DP5").getDateValue().getTime();
				}
				var date2_ms = dSelectedDate.getTime(); // Calculate the difference in milliseconds  
				var difference_ms = date2_ms - date1_ms; // Convert back to days and return   
				var days = Math.round(difference_ms / one_day);
				if (days < 180 && days > 0) {
					oEvent.getSource().setDateValue(dSelectedDate);
				} else {
					oEvent.getSource().setDateValue();
					MessageToast.show(this.getMessage("timeError"));
				}
			} else {
				oEvent.getSource().setDateValue(dSelectedDate);
			}
		},
		_getUTCDate: function(sDate) {
			if (sDate && sDate !== null) {
				return new Date(Date.UTC(sDate.getFullYear(), sDate.getMonth(), sDate.getDate(), sDate.getHours(),
					sDate.getMinutes(), sDate.getSeconds()));
			} else {
				return sDate;
			}
		},
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath();
			this.visaInit(this.getView().getModel().getProperty(sPath + "/VisaType"));
			this.setSelected(this.getView().getModel().getProperty(sPath + "/Paid"));
			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},
		onFileDeleted: function(oEvent) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			visarequest.ZHCM_Visa_Request.model.FileUploadHelper.deleteUploadedFile(oEvent, this, this.sEmployeeId, this.sVisaRequest,
				resourceBundle);
		},
		onChangeFile: function(oEvent) {
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			visarequest.ZHCM_Visa_Request.model.FileUploadHelper.beforeUploadFile(oEvent, this, this.sEmployeeId, this.sVisaRequest,
				resourceBundle);
		},
		/*	AttachmentModel : function ( EmployeeId, VisaRequest) {
			var oDataModel = this.getView().getModel(),
					Attachment = new JSONModel({
						IsCreatable: false
					}),
					oFunctionParams = {};
				
				this.getView().setModel(Attachment, "Attachment");
				var that = this;
				var paramaters = {"EmployeeId" : EmployeeId, "VisaRequest" : VisaRequest};
				oFunctionParams.urlParameters=paramaters;
				oFunctionParams.method = "GET";
				oFunctionParams.success = function(oData,oResponse) {
					delete oData.__metadata;
					for (var i = 0; i < oData.results.length; i++){
                        if (!oData.results[i].Url){
                            oData.results[i].Url = oData.results[i].__metadata.media_src;
                        }
                    }
                    Attachment.setData(oData);
					that.getView().setModel(Attachment, "Attachment");
				};
				
				oFunctionParams.error = function(oError) {
					
					that.getView()._oErrorHandler._bMessageOpen = true;
					
					var jsonError = JSON.parse(oError.responseText);
					Attachment.setData({
						IsCreatable: false,
						ErrorMessage: jsonError.error.message.value
					});
					
					that.getView().setModel(Attachment, "Attachment");
					
					MessageBox.error(
						// this._sErrorText,
						jsonError.error.message.value,
						{
							id : "serviceErrorMessageBox",
							details : oError,
							styleClass : that.getView().getContentDensityClass(),
							actions : [MessageBox.Action.CLOSE],
							onClose : function () {
								that.getView()._oErrorHandler._bMessageOpen = false;
								that.getView().getRouter().getTargets().display("error");
							}.bind(that)
						}
					);
					
					
				};
				oFunctionParams.async = false;
				
				oDataModel.metadataLoaded().then( function() {
					oDataModel.callFunction("/GetAttachment", oFunctionParams);
				}.bind(this));
				
			},*/
		onUploadComplete: function(oEvent) {
			//Check if the Upload is success
			var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var parameters = oEvent.getParameter("mParameters");
			var status = parameters.status;
			if (status === 201) {
				// Call Upload success
				visarequest.ZHCM_Visa_Request.model.FileUploadHelper.fileUploadSuccess(oEvent, this, resourceBundle);
			} else {
				// Call Upload Failure
			//	visarequest.ZHCM_Visa_Request.model.FileUploadHelper.fileUploadFailure(oEvent, this, resourceBundle);
				var parser = new DOMParser();
				var xmlDoc = parser.parseFromString(oEvent.getParameters().files[0].responseRaw,"text/xml");
				this.showError(xmlDoc.getElementsByTagName("message")[0].innerHTML);
			}

			//reload the attachments
			this.callValueHelps("/VisaRequestSet(EmployeeId='" + this.sEmployeeId + "',VisaRequest='" + this.sVisaRequest + "')");
		}
	});

});